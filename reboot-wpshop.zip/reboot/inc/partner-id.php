<?php

define( 'WPSHOP_PARTNER', '21857' );